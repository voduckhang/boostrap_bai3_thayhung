<?php
include_once "../Controller/ketnoi.php";

if(isset($_POST["submit"]))
{
	$email=$_POST["email"];
    $mk=$_POST["mk"];

	if(isset($email) &&isset($mk))
	{
		$sql="SELECT  *FROM users WHERE email ='$email' AND password ='$mk' ";
		$query=mysqli_query($conn,$sql);
		$rows=mysqli_num_rows($query);
		if($rows=mysqli_num_rows($query)>0)
		{
			$_SESSION["email"]=$email;
			$_SESSION["password"]=$mk;
			header('location: ../View/Trangchu.php');
			
		}
		else{
			echo '<center>Tài khoản bạn không tồn tại hoặc sai thông tin đăng nhập!!!!</center>';
		}
	}
		
}
?>