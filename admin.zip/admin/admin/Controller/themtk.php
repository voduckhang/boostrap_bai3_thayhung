<?php 
include_once '../Controller/ketnoi.php';
if(isset($_POST['submit'])){
    $id=$_POST['id'];
    $full_name=$_POST['full_name'];   
    $email=$_POST['email'];
    $phone=$_POST['phone'];
    $address=$_POST['address'];
    $password=$_POST['password'];
    if(isset($id) &&  isset($full_name)   && isset($email) && isset($phone)
    && isset($address)&& isset($password))
    {
       
        $sql="INSERT INTO users(id,full_name,email,phone,address,password)
        VALUES('$id','$full_name','$email','$phone','$address','$password')";
        $query= mysqli_query($conn, $sql);
        header("location: ../View/Thanhvien.php");
    }
    }   
?>   