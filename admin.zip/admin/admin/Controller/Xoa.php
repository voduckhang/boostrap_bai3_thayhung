<?php
$id=$_GET['id'];
include_once '../Controller/ketnoi.php';

$sql="DELETE FROM products WHERE id=$id";
$query=mysqli_query($conn,$sql);
header('location: ../View/Sanpham.php');
?>