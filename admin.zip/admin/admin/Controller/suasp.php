<?php

include_once '../Controller/ketnoi.php';

if(isset($_POST['submit'])){
    $id=$_POST['id'];
    $name=$_POST['name'];
    $description=$_POST['description'];
    $unit_price=$_POST['unit_price'];   
    $promotion_price=$_POST['promotion_price'];
    if($_FILES['image']['name']==''){
        $error_anh_sp='<span style="color:red;">(*)</span>';
    }
    else{
        $image=$_FILES['image']['name'];
        $tmp_name=$_FILES['image']['tmp_name'];
        move_uploaded_file($tmp_name,'images/products/'.$image);
    }
   

    $unit=$_POST['unit'];

    if(isset($id) && isset($name) && isset($description) && isset($unit_price) && isset($promotion_price) && isset($image)  && isset($unit) )
    {
       
        $sql="UPDATE products SET name='$name',description='$description',unit_price='$unit_price',promotion_price='$promotion_price',image='$image',unit='$unit'  id=$id ";
        $query=mysqli_query($conn, $sql);
        header("location: ../View/Sanpham.php");
    }
}
?>