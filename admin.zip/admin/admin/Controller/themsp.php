<?php 

include_once '../Controller/ketnoi.php';

if(isset($_POST['submit'])){
    $id=$_POST['id'];
    $name=$_POST['name'];
    $description=$_POST['description'];
    $unit_price=$_POST['unit_price'];   
    $promotion_price=$_POST['promotion_price'];
    if($_FILES['image']['name']==''){
        $error_anh_sp='<span style="color:red;">(*)</span>';
    }
    else{
        $image=$_FILES['image']['name'];
        $tmp_name=$_FILES['image']['tmp_name'];
    }
   

    $unit=$_POST['unit'];
    
    

    
    
    if(isset($id) && isset($name) && isset($description) && isset($unit_price) && isset($promotion_price) && isset($image)  && isset($unit) )
    {
        move_uploaded_file($tmp_name,'View/images/products/'.$image);
        
        $sql1="INSERT INTO products(id,name,description,unit_price,promotion_price,image,unit)
        VALUES('$id','$name','$description','$unit_price','$promotion_price','$image','$unit')";
        $query= mysqli_query($conn, $sql1);
        header("location: ../View/Sanpham.php");
}
       
    }
    
?>   