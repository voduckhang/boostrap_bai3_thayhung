<?php 
include_once '../Controller/ketnoi.php';    
if(isset($_POST['submit'])){
    $mansx=$_POST['mansx'];
    $tennsx=$_POST['tennsx'];
    $quocgia=$_POST['quocgia'];
    $mota=$_POST['mota'];
    if(isset ($mansx) && isset ($tennsx) && isset ($quocgia) && isset ($mota) ){
        $sql="INSERT INTO nsx VALUES ('$mansx','$tennsx','$quocgia','$mota')";
        $query= mysqli_query($conn, $sql);
        header('location: ../View/NSX.php');
    }
}