<?php 
include_once '../Controller/ketnoi.php';    
$sql="SELECT  count(id) as Sl FROM users";
$query= mysqli_query($conn, $sql);
$row= mysqli_fetch_array($query);
if($row['Sl']==0)
{
    $id=1;
}
else{
    $id=$row['Sl'];
    $id++;
       
}

?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
<head>
<?php include 'layouts/headeradmin.php' ?>
</head>
<body>
    <!-- Left Panel -->

 
    <!-- Left Panel -->
    <!-- Right Panel -->
    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <?php include 'layouts/menutopadmin.php' ?>
        <!-- Header-->
        <div class="breadcrumbs">
            <div class="breadcrumbs-inner">
                <div class="row m-0">
                    <div class="col-sm-4">
                        <div class="page-header float-left">
                            <div class="page-title">
                            <h1>
                            <button  type="submit" class="btn btn-success" onclick="location.href='Thanhvien.php'" ><i class=" fa fa-undo"></i> Back </button></h1>
                            </div>
                            
                        </div>
                    </div>
                    <div class="col-sm-8">
                        <div class="page-header float-right">
                            <div class="page-title">
                                <ol class="breadcrumb text-right">
                                    <li><a href="#">Tài Khoản</a></li>
                                    
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="content">
            <div class="animated fadeIn">
                <div class="row">

                    <div class="col-md-12">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header bg-primary">
                            <strong class="card-tille text-light" > Thông tin tài khoản </strong>
                            </div>
                            <div class="card-body card-block">
                                <form action="../Controller/themtk.php" method="post" enctype="multipart/form-data" class="form-horizontal">
                                    
                                    <div class="row form-group">
                                        <div class="col col-md-2"><label for="text-input" class=" form-control-label">ID</label></div>
                                        <div class="col-12 col-md-9"><input type="text"  name="id"  class="form-control"value='<?php echo $id ?>'></div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-2"><label for="text-input" class=" form-control-label">Tên Tài Khoản</label></div>
                                        <div class="col-12 col-md-9"><input type="text"  name="full_name"  class="form-control"></div>
                                    </div>
                                    
                                   

                                    
                                    <div class="row form-group">
                                        <div class="col col-md-2"><label for="text-input" class=" form-control-label">Địa chỉ</label></div>
                                        <div class="col-12 col-md-9"><input type="text"  name="address"  class="form-control"></div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-2"><label for="text-input" class=" form-control-label">Email</label></div>
                                        <div class="col-12 col-md-9"><input type="text"  name="email"  class="form-control"></div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-2"><label for="text-input" class=" form-control-label">Số Điện Thoại</label></div>
                                        <div class="col-12 col-md-9"><input type="text"  name="phone"  class="form-control"></div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-2"><label for="text-input" class=" form-control-label">Mật khẩu</label></div>
                                        <div class="col-12 col-md-9"><input type="password"  name="password" class="form-control"></div>
                                    </div>
                                
                            
                                    <div class="row form-group">
                                    <button type="submit" name="submit" value="submit" class="btn btn-primary" style="margin-left:10px" >
                                            <i class="fa fa-dot-circle-o"></i> Submit
                                        </button>
                                    <button type="reset" class="btn btn-danger"style="margin-left:10px" >
                                        <i class="fa fa-ban"></i> Reset
                                    </button>
                                    </div>
                                </div>
                            </div>          
                        </div>
                    </div>

                    
                </div>
            </div><!-- .animated -->
        </div><!-- .content -->


        <div class="clearfix"></div>
        

        <!--Footder-->
<?php include 'layouts/footeradmin.php' ?>
<!--#Footder-->

    </div><!-- /#right-panel -->

    <!-- Right Panel -->

    <!-- Scripts -->
    <?php include 'layouts/scriptsadmin.php' ?>


   
</body>
</html>