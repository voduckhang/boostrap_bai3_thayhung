
<?php
include_once '../Controller/ketnoi.php';


$id=$_GET['id'];
$sql="SELECT *FROM products WHERE id=$id";
$query=mysqli_query($conn, $sql);
$row= mysqli_fetch_array($query);

?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
<head>
<?php include 'layouts/headeradmin.php' ?>
</head>
<body>
    <!-- Left Panel -->

    <?php include 'layouts/menuadmin.php' ?>
    <!-- Left Panel -->
    <!-- Right Panel -->
    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <?php include 'layouts/menutopadmin.php' ?>
        <!-- Header-->
        <div class="breadcrumbs">
            <div class="breadcrumbs-inner">
                <div class="row m-0">
                    <div class="col-sm-4">
                        <div class="page-header float-left">
                            <div class="page-title">
                            <h1>
                            <button  type="submit" class="btn btn-success" onclick="location.href='Sanpham.php'" ><i class=" fa fa-undo"></i> Back </button></h1>
                            </div>
                            
                        </div>
                    </div>
                    <div class="col-sm-8">
                        <div class="page-header float-right">
                            <div class="page-title">
                                <ol class="breadcrumb text-right">
                                    <li><a href="#">Sản phẩm</a></li>
                                    <li class="active">Sản phẩm mới</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="content">
            <div class="animated fadeIn">
                <div class="row">

                <div class="col-md-12">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header bg-primary">
                            <strong class="card-tille text-light" > Thông tin Sản Phẩm </strong>
                            </div>
                            <div class="card-body card-block">
                                <form action="../Controller/themsp.php" method="post" enctype="multipart/form-data" class="form-horizontal">
                                <div class="row form-group">
                                        <div class="col col-md-2"><label for="text-input" class=" form-control-label">Mã Sản Phẩm</label></div>
                                        <div class="col-12 col-md-9"><input type="text"  name="id" value="<?php echo $id ?>" class="form-control"></label></div>
                                    </div>
                                    
                                    <div class="row form-group">
                                        <div class="col col-md-2"><label for="text-input" class=" form-control-label">Tên Sản Phẩm</label></div>
                                        <div class="col-12 col-md-9"><input type="text"  name="name"  class="form-control"></div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-2"><label for="text-input" class=" form-control-label">Giá</label></div>
                                        <div class="col-12 col-md-9"><input type="text"  name="unit_price" placeholder="$$$" class="form-control"></div>
                                    </div>
                                    
                                    <div class="row form-group">
                                        <div class="col col-md-2"><label for="text-input" class=" form-control-label">Khuyến mãi</label></div>
                                        <div class="col-12 col-md-9"><input type="number"  name="promotion_price" placeholder="$$$"  class="form-control"></div>
                                    </div>

                                    <div class="row form-group">
                                        <div class="col col-md-2"><label for="textarea-input" class=" form-control-label">Nội dung</label></div>
                                        <div class="col-12 col-md-9"><textarea name="description"  rows="9" placeholder="Nhập Mô Tả..." class="form-control"></textarea></div>
                                    </div>
                                    <div class="row form-group">
                                        <label class="col col-md-2" > Ảnh mô tả</label>
                                        <input type="file" name="image" class="col-12 col-md-9">
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-2"><label for="text-input" class=" form-control-label">Đơn vị</label></div>
                                        <div class="col-12 col-md-9"><input type="text"  name="unit"  class="form-control"></div>
                                    </div>
                                    <div class="row form-group">
                                    <button type="submit" name="submit" value="submit" class="btn btn-primary" style="margin-left:10px" >
                                            <i class="fa fa-dot-circle-o"></i> Submit
                                        </button>
                                    <button type="reset" class="btn btn-danger"style="margin-left:10px" >
                                        <i class="fa fa-ban"></i> Reset
                                    </button>
                                    </div>
                                </div>
                            </div>          
                        </div>
                    </div>


                </div>
            </div><!-- .animated -->
        </div><!-- .content -->


        <div class="clearfix"></div>
        

        <!--Footder-->
<?php include 'layouts/footeradmin.php' ?>
<!--#Footder-->

    </div><!-- /#right-panel -->

    <!-- Right Panel -->

    <!-- Scripts -->
    <?php include 'layouts/scriptsadmin.php' ?>


    


</body>
</html>