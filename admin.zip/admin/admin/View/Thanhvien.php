<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
<head>
<?php include 'layouts/headeradmin.php' ?>
<body>
    <!-- Left Panel -->
    
    <?php 
include_once '../Controller/ketnoi.php';
$sql="SELECT *FROM users  ORDER BY id";
$query= mysqli_query($conn, $sql);
?>
<!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <?php include 'layouts/menutopadmin.php' ?>
        <!-- /header -->
        <!-- Header-->

        <div class="breadcrumbs">
            <div class="breadcrumbs-inner">
                
                <div class="row m-0">
                    <div class="col-sm-4">                       
                        <div class="page-header float-left">
                            <div class="page-title">                               
                                <h1>Danh sách Thành viên</h1>
                            </div>
                            
                        </div>
                    </div>
                    <div class="col-sm-8">
                        <div class="page-header float-right">
                            <div class="page-title">
                                <ol class="breadcrumb text-right">
                                    <li><a href="#">Quản lý</a></li>
                                    <li><a href="#">Tài khoản</a></li>
                                    <li class="active">Danh sách</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
            
        <div class="card-header">
            <button  type="submit" class="btn btn-success" onclick="location.href='Themtaikhoan.php'" ><i class=" fa fa-plus-square"> Thêm tài khoản</i></button>
        </div>           
            <div class="animated fadeIn">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            
                            <div class="table-stats order-table ov-h">
                                <table class="table ">
                                    <thead>
                                    <tr>
                                            <th>Id</th>
                                            <th>Tên</th>
                                            <th>Email</th>
                                            <th>Số điện thoại</th>
                                            
                                            <th>Xóa</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                        while($row=mysqli_fetch_array($query)){
                        ?>
                                        <tr>
                                            <td><?php echo $row['id'];?></td>                                          
                                            <td> <?php echo $row['full_name'];?></td>
                                            <td> <?php echo $row['email'];?></td>
                                            <td><?php echo $row['phone'];?></td>
                                          
                                            
                                            
                                           
                                            <td><a type="submit" class="btn btn-danger" onclick="return xoaSanPham();" href='../Controller/Xoatk.php?id=<?php echo $row['id'];?>'><i class="fa fa-trash-o"> </i></a></td>
                                            
                                        </tr>
                                    </tbody>
                                    <?php
                        }
                        ?>
                                </table>
                            </div> <!-- /.table-stats -->
                        </div>
                    </div>
                    <a href="index.php"> <label>Quay lại đăng nhập</label></a>
        </div>
    </div><!-- .animated -->
</div><!-- .content -->

<div class="clearfix"></div>
<!--Footder-->
<?php include 'layouts/footeradmin.php' ?>
<!--#Footder-->
</div><!-- /#right-panel -->

<!-- Right Panel -->

<!-- Scripts -->
<?php include 'layouts/scriptsadmin.php' ?>
<script>
    function xoaSanPham(){
        var conf=confirm("Bạn có chắc muốn xóa ");
        return conf;
    }
</script>
</body>
</html>
