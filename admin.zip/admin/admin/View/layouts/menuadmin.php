
<aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div id="main-menu" class="main-menu collapse navbar-collapse ">
                <ul class="nav navbar-nav active dropdown">
                    <li>
                        <a href="Trangchu.php"><i class="menu-icon fa fa-home"></i>Trang chủ</a>
                    </li>
                    <li class="menu-item-has-children  ">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa   fa-list-ul"></i>Quản Lý</a>
                        <ul class="sub-menu children dropdown-menu">
                        
                      
                            <li><i class="fa fa-gift"></i><a href="Sanpham.php">Sản Phẩm</a></li>
                            
                        </ul>
                    </li>
                   
                    <li class="menu-item-has-children  " >
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa  fa-cogs"></i>Thiết lập</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-power-off"></i><a href="dangxuat.php">Đăng xuất</a></li>
                            
                        </ul>
                    </li>
                   
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside>