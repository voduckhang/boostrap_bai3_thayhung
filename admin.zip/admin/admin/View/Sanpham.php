<script>
    function xoaSanPham(){
        var conf=confirm("Bạn có chắc muốn xóa sản phẩm này không");
        return conf;
    }
</script>
<?php 
include_once '../Controller/ketnoi.php';
$sql="SELECT * FROM products ORDER BY id DESC";
$query= mysqli_query($conn, $sql);
?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
<head>
<?php include 'layouts/headeradmin.php' ?>
</head>
<body>
    <!-- Left Panel -->

    <?php include 'layouts/menuadmin.php' ?>
    <!-- Left Panel -->
    <!-- Right Panel -->
    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <?php include 'layouts/menutopadmin.php' ?>
        <!-- Header-->

        <div class="breadcrumbs">
            <div class="breadcrumbs-inner">
                <div class="row m-0">
                    <div class="col-sm-4">
                        <div class="page-header float-left">
                            <div class="page-title">
                                <h1>Danh sách sản phẩm</h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8">
                        <div class="page-header float-right">
                            <div class="page-title">
                                <ol class="breadcrumb text-right">
                                    <li><a href="#">Sản phẩm</a></li>
                                    <li class="active">Danh sách</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="animated fadeIn">
                <div class="row">

                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                            <button  type="submit" class="btn btn-success" onclick="location.href='ThemSP.php'" ><i class=" fa fa-plus-square"> Thêm Sản Phẩm</i></button>
                            </div>
                            <div class="card-body">
                                <table id="bootstrap-data-table" class="table table-striped table-bordered">
                                    <thead>
                                    
                                        <tr>
                                            <th>ID</th>
                                            <th>Tên</th> 
                                            <th>Đơn vị</th>                          
                                            <th>Giá</th>
                                            <th>Ảnh</th>
                                                                                    
                                            <th>Xóa</th>
                                        </tr>
                                    </thead>
                        <tbody>
                        <?php
                        while($row=mysqli_fetch_array($query)){
                        ?>
                        
                                    <tr>
                                    <td><?php echo $row['id'];?></td>
                                    <td><?php echo $row['name']; ?></td>
                                    <td><?php echo $row['unit'];?></td>
                                   
                                    <td ><span class="price"><?php  echo number_format( $row['unit_price']);?></span></td>
                                    <td><?php echo $row['image'];?></td>
                                                                     
                                   
                                    <td><a type="submit" class="btn btn-danger" onclick="return xoaSanPham();" href='../Controller/Xoa.php?id=<?php echo $row['id'];?>'><i class="fa fa-trash-o"> </i></a></td>
                                    </tr>
                                                
                        <?php
                        }
                        ?>
                        </tbody> 
                                </table>
                            </div>
                        </div>
                    </div>


                </div>
            </div><!-- .animated -->
        </div><!-- .content -->


        <div class="clearfix"></div>

    <!--Footder-->
<?php include 'layouts/footeradmin.php' ?>
<!--#Footder-->

    </div><!-- /#right-panel -->

    <!-- Right Panel -->

    <!-- Scripts -->
    <?php include 'layouts/scriptsadmin.php' ?>


   


</body>
</html>
